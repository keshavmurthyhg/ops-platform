import os
from flask import Blueprint, render_template, request, jsonify, send_file, current_app
from werkzeug.utils import secure_filename

# Relative import works whether run via root or standalone module packaging
from .module.logic import section_diff_logic, compare_excels, generate_output

excel_compare_bp = Blueprint(
    'excel_compare', 
    __name__,
    template_folder='templates',  # Fallback for standalone mode
    static_folder='statics',
    static_url_path='/excel_compare/static'
)

# Crucial fix: explicitly mapping the tool interface endpoint
@excel_compare_bp.route('/excel-compare')
def index():
    return render_template('excel_compare.html')

@excel_compare_bp.route('/excel_compare/compare', methods=['POST'])
def compare_files():
    if 'oldFile' not in request.files or 'newFile' not in request.files:
        return jsonify({'error': 'Missing files'}), 400

    file1 = request.files['oldFile']
    file2 = request.files['newFile']

    upload_folder = current_app.config.get('UPLOAD_FOLDER', 'uploads')
    os.makedirs(upload_folder, exist_ok=True)

    path1 = os.path.join(upload_folder, secure_filename(file1.filename))
    path2 = os.path.join(upload_folder, secure_filename(file2.filename))
    file1.save(path1)
    file2.save(path2)

    try:
        df1, df2 = compare_excels(path1, path2)
        diff_mask1, diff_mask2, summary, total_diff, removed_rows_data = section_diff_logic(df1, df2)
        zip_path, zip_name = generate_output(path1, path2)
        
        current_app.config['LAST_COMPARE_ZIP'] = zip_path
        current_app.config['LAST_COMPARE_NAME'] = zip_name

        rows_changed = sum(v['modified'] for v in summary.values())
        new_rows = sum(v['added'] for v in summary.values())
        deleted_rows = sum(v['removed'] for v in summary.values())
        
        table_rows = []
        for r in range(len(df2)):
            for c in range(len(df2.columns)):
                if diff_mask2.iloc[r, c] == "modified":
                    table_rows.append({
                        "sheet": "Sheet1",
                        "cell": f"Col {c+1}, Row {r+1}",
                        "oldValue": str(df1.iloc[r, c]) if r < len(df1) and c < len(df1.columns) else "",
                        "newValue": str(df2.iloc[r, c]),
                        "status": "Modified"
                    })

        return jsonify({
            "success": True,
            "metrics": {
                "rowsChanged": rows_changed,
                "columnsChanged": 0,
                "newRows": new_rows,
                "deletedRows": deleted_rows
            },
            "results": table_rows
        })
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@excel_compare_bp.route('/excel_compare/download', methods=['GET'])
def download_report():
    zip_path = current_app.config.get('LAST_COMPARE_ZIP')
    zip_name = current_app.config.get('LAST_COMPARE_NAME', 'Comparison_Report.zip')
    if zip_path and os.path.exists(zip_path):
        return send_file(zip_path, as_attachment=True, download_name=zip_name)
    return jsonify({'error': 'No report available'}), 404