// Click handlers for the custom upload boxes
document.getElementById('drop-zone-old').onclick = () => document.getElementById('oldFile').click();
document.getElementById('drop-zone-new').onclick = () => document.getElementById('newFile').click();

// Display file name when selected
document.getElementById('oldFile').onchange = (e) => {
    document.getElementById('oldFileName').innerText = e.target.files[0]?.name || "No file selected";
};
document.getElementById('newFile').onchange = (e) => {
    document.getElementById('newFileName').innerText = e.target.files[0]?.name || "No file selected";
};

document.getElementById("compareBtn").addEventListener("click", async () => {
    const oldFile = document.getElementById("oldFile").files[0];
    const newFile = document.getElementById("newFile").files[0];
    const statusText = document.getElementById("statusText");

    if (!oldFile || !newFile) {
        statusText.innerText = "Error: Select 2 files";
        return;
    }

    statusText.innerText = "Processing...";
    const formData = new FormData();
    formData.append("oldFile", oldFile);
    formData.append("newFile", newFile);

    try {
        const response = await fetch("/excel_compare/compare", { method: "POST", body: formData });
        const data = await response.json();

        if (data.success) {
            statusText.innerText = "Complete!";
            // Update KPIs
            document.getElementById("rowsChanged").innerText = data.metrics.rowsChanged;
            document.getElementById("newRows").innerText = data.metrics.newRows;
            document.getElementById("deletedRows").innerText = data.metrics.deletedRows;

            // Update Table
            const tbody = document.getElementById("resultTable");
            tbody.innerHTML = data.results.map(row => `
                <tr>
                    <td>${row.sheet}</td>
                    <td><b>${row.cell}</b></td>
                    <td style="color: #ef4444">${row.oldValue}</td>
                    <td style="color: #10b981">${row.newValue}</td>
                    <td><span class="status-badge modified">${row.status}</span></td>
                </tr>
            `).join('') || '<tr><td colspan="5" class="empty-state">No differences found in cell content.</td></tr>';
        }
    } catch (err) {
        statusText.innerText = "Server Error";
    }
});

document.getElementById("downloadBtn").onclick = () => {
    window.location.href = "/excel_compare/download";
};